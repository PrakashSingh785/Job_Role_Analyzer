import spacy
import json

nlp = spacy.load("en_core_web_sm")

def analyze_resume(text, job_role):
    with open("sample_roles.json") as f:
        role_data = json.load(f)

    keywords = role_data.get(job_role, [])
    doc = nlp(text.lower())

    matched_keywords = [kw for kw in keywords if kw in text.lower()]
    score = len(matched_keywords) / len(keywords) * 100 if keywords else 0

    return {
        "matched_keywords": matched_keywords,
        "score": round(score, 2),
        "total_keywords": len(keywords)
    }