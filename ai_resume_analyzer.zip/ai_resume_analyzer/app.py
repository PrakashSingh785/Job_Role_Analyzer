from flask import Flask, request, render_template
import os
from werkzeug.utils import secure_filename
from resume_parser import extract_resume_text
from analyzer import analyze_resume

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    file = request.files['resume']
    job_role = request.form['job_role']

    filepath = os.path.join(UPLOAD_FOLDER, secure_filename(file.filename))
    file.save(filepath)

    resume_text = extract_resume_text(filepath)
    result = analyze_resume(resume_text, job_role)

    return render_template('index.html', result=result, job_role=job_role)

if __name__ == '__main__':
    app.run(debug=True)